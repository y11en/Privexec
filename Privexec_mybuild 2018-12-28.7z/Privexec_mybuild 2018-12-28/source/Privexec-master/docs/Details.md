# Details

`CreateProcessAsUser` Stack:

![Stask](./images/austack.png)
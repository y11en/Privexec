# Changelog

## 2018-12-28

1. Privexec/WSUDO support `Less Privileged AppContainer`
2. Privexec AppContainer supports more capabilities to choose from

## 2018-12-22

1.  Privexec (GUI) AppContainer support Restricted Capabilities.  
>`Recommended Capabilities` can be selected at the same time as `Appmanifest`, the `Capabilities `will be merged
2.  Privexec (GUI) Support Dropfiles. Appx edit box accept `*.xml;*.appmanifest` if it is activated. Command edit box accept other files.